package sistema.models;

public class Clientes {
    private String data;
    private String hora;
    private int pressaoSistolica;
    private int pressaoDiastolica;
    private String estresseSouN;
    
    public String getData(){
        return data;
    }
    
    public void setData(String data){
        this.data = data;
    }
    
    public String getHora(){
        return hora;
    }
    
    public void setHora(String hora){
        this.hora = hora;
    }
    
    public int getPressaoSistolica(){
        return pressaoSistolica;
    }
    
    public void setPressaoSistolica(int pressaoSistolica){
        this.pressaoSistolica = pressaoSistolica;
    }
    
    public int getPressaoDiastolica(){
        return pressaoDiastolica;
    }
    
    public void setPressaoDiastolica(int pressaoDiastolica){
        this.pressaoDiastolica = pressaoDiastolica;
    }
    
    public String getEstresseSouN(){
        return estresseSouN;
    }
    
    public void setEstresseSouN(String estresseSouN){
        this.estresseSouN = estresseSouN;
    }
}
